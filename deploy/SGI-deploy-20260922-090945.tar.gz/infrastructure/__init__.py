"""Infraestrutura do SGI."""
