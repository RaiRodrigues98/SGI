import { useRef, useState } from "react";
import { Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { ContagemItem, ResumoContagem } from "@/types/inventory";

interface ItensContadosListProps {
  itens: ContagemItem[];
  resumo: ResumoContagem;
  bloqueado: boolean;
  onCancelar: (
    id: string,
  ) => Promise<{ ok: boolean; erro?: string }>;
}

export function ItensContadosList({
  itens,
  resumo,
  bloqueado,
  onCancelar,
}: ItensContadosListProps) {
  const [selecionado, setSelecionado] =
    useState<ContagemItem | null>(null);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);
  const emCurso = useRef(false);

  async function confirmar() {
    if (!selecionado || bloqueado || emCurso.current) {
      return;
    }

    emCurso.current = true;
    setEnviando(true);
    setErro(null);

    try {
      const resultado = await onCancelar(selecionado.id);

      if (!resultado.ok) {
        setErro(
          resultado.erro ||
            "Não foi possível cancelar a contagem.",
        );
        return;
      }

      setSucesso(
        `Contagem #${selecionado.id} cancelada com sucesso.`,
      );
      setSelecionado(null);
    } catch (error) {
      setErro(
        error instanceof Error
          ? error.message
          : "Não foi possível cancelar a contagem.",
      );
    } finally {
      emCurso.current = false;
      setEnviando(false);
    }
  }

  return (
    <section className="space-y-3">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-primary">
        Itens registrados nesta localização
      </h2>

      {sucesso ? (
        <p role="status" className="text-sm text-primary">
          {sucesso}
        </p>
      ) : null}

      <AlertDialog
        open={selecionado !== null}
        onOpenChange={(aberto) => {
          if (!aberto && !emCurso.current) {
            setSelecionado(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Cancelar registro de contagem?
            </AlertDialogTitle>

            <AlertDialogDescription>
              Registro #{selecionado?.id} · Produto{" "}
              {selecionado?.codigo} · Lote{" "}
              {selecionado?.lote || "—"} · Quantidade{" "}
              {selecionado?.quantidade}. O registro será
              cancelado e deixará de compor os totais desta
              localização.
            </AlertDialogDescription>
          </AlertDialogHeader>

          {erro ? (
            <p role="alert" className="text-sm text-destructive">
              {erro}
            </p>
          ) : null}

          <AlertDialogFooter>
            <Button
              type="button"
              variant="outline"
              disabled={enviando}
              onClick={() => setSelecionado(null)}
            >
              Voltar
            </Button>

            <Button
              type="button"
              variant="destructive"
              disabled={bloqueado || enviando}
              onClick={() => void confirmar()}
            >
              {enviando
                ? "Cancelando..."
                : "Confirmar cancelamento"}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {itens.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border bg-card px-3 py-8 text-center text-sm text-muted-foreground">
          Nenhum item registrado ainda.
        </p>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {itens.map((item) => (
            <li
              key={item.id}
              className="relative grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 rounded-lg border border-border bg-card px-4 py-3 pr-14 shadow-xs"
            >
              <div className="min-w-0 space-y-1">
  <p className="break-words text-sm font-medium text-muted-foreground">
    <span className="font-semibold text-primary">SKU:</span>{" "}
    {item.codigo}
  </p>

  <p className="break-words text-sm font-medium text-muted-foreground">
    <span className="font-semibold text-primary">Lote:</span>{" "}
    {item.lote || "—"}
  </p>

  <p className="break-words text-sm font-medium text-muted-foreground">
    <span className="font-semibold text-primary">Descrição:</span>{" "}
    {item.descricao || "—"}
  </p>
</div>

              <div className="shrink-0 text-right">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Qtd.
                </p>

                <p className="font-mono text-xl font-bold text-gold">
                  {item.quantidade}
                </p>
              </div>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute bottom-2 right-2 size-10 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                disabled={bloqueado || enviando}
                aria-label={`Cancelar contagem ${item.id} do produto ${item.codigo}`}
                title="Cancelar contagem"
                onClick={() => {
                  setErro(null);
                  setSucesso(null);
                  setSelecionado(item);
                }}
              >
                <Trash2
                  className="size-5"
                  aria-hidden="true"
                />
              </Button>
            </li>
          ))}
        </ul>
      )}

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-border bg-card px-4 py-3">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Itens registrados
          </p>

          <p className="font-mono text-2xl font-bold text-primary">
            {resumo.itensRegistrados}
          </p>
        </div>

        <div className="rounded-lg border border-border bg-card px-4 py-3">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Quantidade total
          </p>

          <p className="font-mono text-2xl font-bold text-gold">
            {resumo.quantidadeTotal}
          </p>
        </div>
      </div>
    </section>
  );
}