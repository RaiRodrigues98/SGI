import type ExcelJSTypes from "exceljs";
import { consultarInventarioDetalhe, consultarSnapshotInventario } from "@/services/inventarioService";
import { buscarRodadasInventario } from "@/services/recontagemService";
import { buscarAnaliseOficial } from "@/services/oficialService";
import { buscarAnaliseGestor } from "@/services/gestorService";
import { buscarResultadoFinalIndicadores } from "@/services/indicadoresService";

type AnaliseOficial = Awaited<ReturnType<typeof buscarAnaliseOficial>>;
type ItemAnaliseOficial = AnaliseOficial["itens"][number];
type AnaliseGestor = Awaited<ReturnType<typeof buscarAnaliseGestor>>;
type ItemAnaliseGestor = AnaliseGestor["itens"][number];

const COR_PRIMARIA = "25206E";
const COR_SECUNDARIA = "E8E6F7";
const COR_CABECALHO = "F1F5F9";
const COR_BORDA = "CBD5E1";
const COR_TEXTO = "0F172A";

function chaveItem(codigo: string, lote: string | null | undefined) {
  return `${codigo.trim()}::${String(lote ?? "").trim()}`;
}

function dataExcel(valor: string | null | undefined): Date | null {
  if (!valor) return null;
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? null : data;
}

function estilizarTitulo(planilha: ExcelJSTypes.Worksheet, ultimaColuna: number, titulo: string, subtitulo: string) {
  planilha.mergeCells(1, 1, 1, ultimaColuna);
  planilha.getCell(1, 1).value = titulo;
  planilha.getCell(1, 1).font = { bold: true, color: { argb: "FFFFFFFF" }, size: 16 };
  planilha.getCell(1, 1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: `FF${COR_PRIMARIA}` } };
  planilha.getCell(1, 1).alignment = { vertical: "middle", horizontal: "left" };
  planilha.getRow(1).height = 28;

  planilha.mergeCells(2, 1, 2, ultimaColuna);
  planilha.getCell(2, 1).value = subtitulo;
  planilha.getCell(2, 1).font = { color: { argb: "FF475569" }, italic: true, size: 10 };
  planilha.getCell(2, 1).alignment = { vertical: "middle", horizontal: "left" };
  planilha.getRow(2).height = 22;
}

function estilizarCabecalho(planilha: ExcelJSTypes.Worksheet, linha: number, primeiraColuna: number, ultimaColuna: number) {
  const row = planilha.getRow(linha);
  row.height = 30;
  for (let coluna = primeiraColuna; coluna <= ultimaColuna; coluna += 1) {
    const celula = row.getCell(coluna);
    celula.font = { bold: true, color: { argb: `FF${COR_TEXTO}` }, size: 10 };
    celula.fill = { type: "pattern", pattern: "solid", fgColor: { argb: `FF${COR_CABECALHO}` } };
    celula.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
    celula.border = {
      top: { style: "thin", color: { argb: `FF${COR_BORDA}` } },
      left: { style: "thin", color: { argb: `FF${COR_BORDA}` } },
      bottom: { style: "thin", color: { argb: `FF${COR_BORDA}` } },
      right: { style: "thin", color: { argb: `FF${COR_BORDA}` } },
    };
  }
}

function estilizarDados(planilha: ExcelJSTypes.Worksheet, linhaInicial: number, ultimaColuna: number) {
  for (let linha = linhaInicial; linha <= planilha.rowCount; linha += 1) {
    const row = planilha.getRow(linha);
    for (let coluna = 1; coluna <= ultimaColuna; coluna += 1) {
      const celula = row.getCell(coluna);
      celula.alignment = { vertical: "top", wrapText: true };
      celula.border = {
        bottom: { style: "hair", color: { argb: "FFE2E8F0" } },
      };
    }
  }
}

function largura(planilha: ExcelJSTypes.Worksheet, larguras: number[]) {
  larguras.forEach((valor, indice) => {
    planilha.getColumn(indice + 1).width = valor;
  });
}

function ordinal(numero: number) {
  return `${numero}ª Contagem${numero === 5 ? " - física" : ""}`;
}

export async function exportarAnaliseInventarioExcel(idInventario: number): Promise<void> {
  if (!Number.isInteger(idInventario) || idInventario <= 0) {
    throw new Error("Inventário inválido para exportação.");
  }

  const [detalhe, snapshot, historicoRodadas] = await Promise.all([
    consultarInventarioDetalhe(idInventario),
    consultarSnapshotInventario(idInventario),
    buscarRodadasInventario(idInventario),
  ]);

  const tipo = String(detalhe.tipo).trim().toUpperCase();
  const rodadasOrdenadas = [...historicoRodadas.rodadas].sort(
    (a, b) => a.numero_rodada - b.numero_rodada,
  );

  const analises: AnaliseOficial[] = tipo === "OFICIAL"
    ? await Promise.all(
        rodadasOrdenadas.map((rodada) =>
          buscarAnaliseOficial(idInventario, rodada.id_rodada),
        ),
      )
    : [];

  const [gestorResultado, finalResultado] = await Promise.allSettled([
    tipo === "OFICIAL" ? buscarAnaliseGestor(idInventario) : Promise.resolve(null),
    String(detalhe.status).trim().toUpperCase() === "FINALIZADO"
      ? buscarResultadoFinalIndicadores(idInventario)
      : Promise.resolve(null),
  ]);

  const gestor = gestorResultado.status === "fulfilled" ? gestorResultado.value : null;
  const resultadoFinal = finalResultado.status === "fulfilled" ? finalResultado.value : null;

  const [{ default: ExcelJS }, { saveAs }] = await Promise.all([
    import("exceljs"),
    import("file-saver"),
  ]);

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "SGI - Sistema de Governança de Inventário";
  workbook.created = new Date();
  workbook.modified = new Date();

  const resumo = workbook.addWorksheet("Resumo do inventário", {
    views: [{ state: "frozen", ySplit: 3 }],
    properties: { defaultRowHeight: 20 },
  });
  estilizarTitulo(
    resumo,
    6,
    `Resumo do inventário ${detalhe.codigo_inventario}`,
    `Gerado pelo SGI em ${new Date().toLocaleString("pt-BR")}`,
  );
  largura(resumo, [28, 28, 28, 28, 28, 28]);

  const secoes: Array<[string, Array<[string, unknown]>]> = [
    ["Identificação", [
      ["ID", detalhe.id_inventario],
      ["Código", detalhe.codigo_inventario],
      ["Cliente", detalhe.cliente],
      ["Cliente ID", detalhe.cliente_id],
      ["Armazém", detalhe.armazem],
      ["Descrição", detalhe.descricao ?? "-"],
      ["Tipo", detalhe.tipo],
      ["Status", detalhe.status],
    ]],
    ["Período e responsáveis", [
      ["Criado em", dataExcel(detalhe.data_hora_criacao)],
      ["Criado por", detalhe.criado_por ?? "-"],
      ["Início", dataExcel(detalhe.data_hora_inicio)],
      ["Fim", dataExcel(detalhe.data_hora_fim)],
      ["Finalizado por", detalhe.finalizado_por ?? resultadoFinal?.finalizado_por ?? "-"],
      ["Encaminhado ao gestor em", dataExcel(detalhe.data_hora_encaminhamento_gestor)],
      ["Encaminhado por", detalhe.encaminhado_gestor_por ?? "-"],
    ]],
    ["Operação", [
      ["Fase operacional", detalhe.fase_operacional],
      ["Próxima ação", detalhe.proxima_acao],
      ["Rodada atual", detalhe.rodada_atual],
      ["Total de rodadas", historicoRodadas.total_rodadas],
      ["Localizações", detalhe.total_localizacoes],
      ["Localizações concluídas", detalhe.localizacoes_concluidas],
      ["Localizações pendentes", detalhe.localizacoes_pendentes],
      ["Localizações em contagem", detalhe.localizacoes_em_contagem],
      ["Progresso", Number(detalhe.percentual_progresso) / 100],
      ["Divergências", detalhe.total_divergencias],
      ["Divergências sem decisão", detalhe.divergencias_sem_decisao],
      ["Recontagens pendentes", detalhe.recontagens_pendentes],
    ]],
    ["Resultado", [
      ["Rodada final", resultadoFinal?.rodada_final ?? "-"],
      ["Total de itens", resultadoFinal?.resumo.total_itens ?? snapshot.total],
      ["Itens OK", resultadoFinal?.resumo.ok ?? "-"],
      ["Itens NOK", resultadoFinal?.resumo.nok ?? "-"],
      ["Faltas", resultadoFinal?.resumo.faltas ?? "-"],
      ["Sobras", resultadoFinal?.resumo.sobras ?? "-"],
      ["Divergências finais", resultadoFinal?.resumo.divergencias ?? "-"],
      ["Acuracidade", resultadoFinal ? Number(resultadoFinal.resumo.acuracidade_percentual) / 100 : "-"],
      ["Data de finalização", dataExcel(resultadoFinal?.data_hora_finalizacao)],
    ]],
  ];

  let linhaResumo = 4;
  for (const [titulo, campos] of secoes) {
    resumo.mergeCells(linhaResumo, 1, linhaResumo, 6);
    const tituloCelula = resumo.getCell(linhaResumo, 1);
    tituloCelula.value = titulo;
    tituloCelula.font = { bold: true, color: { argb: `FF${COR_PRIMARIA}` }, size: 12 };
    tituloCelula.fill = { type: "pattern", pattern: "solid", fgColor: { argb: `FF${COR_SECUNDARIA}` } };
    linhaResumo += 1;

    for (let indice = 0; indice < campos.length; indice += 2) {
      const esquerda = campos[indice];
      const direita = campos[indice + 1];

      if (!esquerda) {
        continue;
      }

      resumo.getCell(linhaResumo, 1).value = esquerda[0];
      resumo.getCell(linhaResumo, 1).font = { bold: true, color: { argb: "FF475569" } };
      resumo.getCell(linhaResumo, 2).value = esquerda[1] as ExcelJSTypes.CellValue;
      if (esquerda[1] instanceof Date) resumo.getCell(linhaResumo, 2).numFmt = "dd/mm/yyyy hh:mm:ss";
      if (esquerda[0] === "Progresso" || esquerda[0] === "Acuracidade") resumo.getCell(linhaResumo, 2).numFmt = "0.00%";

      if (direita) {
        resumo.getCell(linhaResumo, 4).value = direita[0];
        resumo.getCell(linhaResumo, 4).font = { bold: true, color: { argb: "FF475569" } };
        resumo.getCell(linhaResumo, 5).value = direita[1] as ExcelJSTypes.CellValue;
        if (direita[1] instanceof Date) resumo.getCell(linhaResumo, 5).numFmt = "dd/mm/yyyy hh:mm:ss";
        if (direita[0] === "Progresso" || direita[0] === "Acuracidade") resumo.getCell(linhaResumo, 5).numFmt = "0.00%";
      }
      linhaResumo += 1;
    }
    linhaResumo += 1;
  }

  const estoque = workbook.addWorksheet("Estoque do inventário", {
    views: [{ state: "frozen", ySplit: 4 }],
    properties: { defaultRowHeight: 20 },
  });
  const colunasEstoque = [
    "ID origem", "Armazém", "Localização", "Código", "Descrição", "Lote",
    "Unidade", "Categoria", "Validade", "Qtd armazenada", "Qtd reservada",
    "Qtd separando", "Qtd bloqueada", "Qtd recebimento", "Saldo inventário",
    "Valor unitário", "Valor total", "Status estoque", "Tipo localização",
  ];
  estilizarTitulo(
    estoque,
    colunasEstoque.length,
    "Estoque do inventário",
    `${detalhe.codigo_inventario} · Snapshot com ${snapshot.total} registro(s)`,
  );
  estoque.addRow([]);
  estoque.addRow(colunasEstoque);
  estilizarCabecalho(estoque, 4, 1, colunasEstoque.length);
  for (const item of snapshot.itens) {
    estoque.addRow([
      item.id_origem, item.c_armazem, item.localizacao, item.codigo,
      item.descricao, item.lote ?? "", item.unidade ?? "", item.categoria ?? "",
      dataExcel(item.validade), item.q_armazenado, item.q_reservado,
      item.q_separando, item.q_bloqueado, item.q_recebimento,
      item.saldo_inventario, item.valor_unitario, item.valor_total,
      item.status_estoque, item.tipo_localizacao ?? "",
    ]);
  }
  estoque.autoFilter = { from: { row: 4, column: 1 }, to: { row: 4, column: colunasEstoque.length } };
  largura(estoque, [12, 12, 18, 18, 40, 18, 12, 18, 14, 15, 14, 14, 14, 15, 16, 16, 16, 14, 18]);
  estoque.getColumn(9).numFmt = "dd/mm/yyyy";
  for (const coluna of [10, 11, 12, 13, 14, 15]) estoque.getColumn(coluna).numFmt = "#,##0.00";
  for (const coluna of [16, 17]) estoque.getColumn(coluna).numFmt = 'R$ #,##0.00';
  estilizarDados(estoque, 5, colunasEstoque.length);

  if (tipo === "OFICIAL") {
    const analisesOrdenadas = [...analises].sort((a, b) => a.numero_rodada - b.numero_rodada);
    const estoqueAgrupado = new Map<string, { codigo: string; lote: string; descricao: string; armazenado: number }>();
    for (const item of snapshot.itens) {
      const chave = chaveItem(item.codigo, item.lote);
      const atual = estoqueAgrupado.get(chave);
      if (atual) atual.armazenado += Number(item.q_armazenado ?? 0);
      else estoqueAgrupado.set(chave, {
        codigo: item.codigo,
        lote: item.lote ?? "",
        descricao: item.descricao,
        armazenado: Number(item.q_armazenado ?? 0),
      });
    }

    const mapasRodadas = analisesOrdenadas.map((analise) =>
      new Map(analise.itens.map((item) => [chaveItem(item.codigo, item.lote), item])),
    );
    const mapaGestor = new Map<string, ItemAnaliseGestor>();
    for (const item of gestor?.itens ?? []) mapaGestor.set(chaveItem(item.codigo, item.lote), item);

    const chaves = new Set<string>(estoqueAgrupado.keys());
    for (const mapa of mapasRodadas) for (const chave of mapa.keys()) chaves.add(chave);
    for (const chave of mapaGestor.keys()) chaves.add(chave);

    const consolidado = workbook.addWorksheet("Inventário", {
      views: [{ state: "frozen", ySplit: 5, xSplit: 4 }],
      properties: { defaultRowHeight: 20 },
    });

    let ultimaColuna = 4;
    for (const analise of analisesOrdenadas) {
      ultimaColuna += analise.numero_rodada >= 3 ? 3 : 2;
      if (analise.numero_rodada === 5) ultimaColuna += 1;
    }
    const colunaFinalInicio = ultimaColuna + 1;
    ultimaColuna += 5;
    estilizarTitulo(
      consolidado,
      ultimaColuna,
      "Inventário consolidado",
      `${detalhe.codigo_inventario} · ${analisesOrdenadas.length} rodada(s) oficial(is)`,
    );

    consolidado.mergeCells(3, 1, 3, 4);
    consolidado.getCell(3, 1).value = "Estoque de referência";
    let coluna = 5;
    for (const analise of analisesOrdenadas) {
      const quantidadeColunas = (analise.numero_rodada >= 3 ? 3 : 2) + (analise.numero_rodada === 5 ? 1 : 0);
      consolidado.mergeCells(3, coluna, 3, coluna + quantidadeColunas - 1);
      consolidado.getCell(3, coluna).value = ordinal(analise.numero_rodada);
      coluna += quantidadeColunas;
    }
    consolidado.mergeCells(3, colunaFinalInicio, 3, ultimaColuna);
    consolidado.getCell(3, colunaFinalInicio).value = "Inventário final";
    estilizarCabecalho(consolidado, 3, 1, ultimaColuna);

    const cabecalho = ["Código", "Descrição", "Lote", "Armazenado"];
    for (const analise of analisesOrdenadas) {
      if (analise.numero_rodada >= 3) cabecalho.push("Realizou contagem?");
      cabecalho.push("Qtd", "Diferença");
      if (analise.numero_rodada === 5) cabecalho.push("Observação");
    }
    cabecalho.push("Qtd", "Diferença", "Situação final", "Decisão gestor", "Justificativa");
    consolidado.addRow(cabecalho);
    estilizarCabecalho(consolidado, 4, 1, ultimaColuna);

    const chavesOrdenadas = [...chaves].sort((a, b) => a.localeCompare(b, "pt-BR"));
    for (const chave of chavesOrdenadas) {
      const estoqueItem = estoqueAgrupado.get(chave);
      const primeiroItem = mapasRodadas.map((mapa) => mapa.get(chave)).find(Boolean) as ItemAnaliseOficial | undefined;
      const gestorItem = mapaGestor.get(chave);
      const ultimaAnaliseItem = [...mapasRodadas].reverse().map((mapa) => mapa.get(chave)).find(Boolean);
      const codigo = estoqueItem?.codigo ?? primeiroItem?.codigo ?? gestorItem?.codigo ?? "";
      const lote = estoqueItem?.lote ?? primeiroItem?.lote ?? gestorItem?.lote ?? "";
      const descricao = estoqueItem?.descricao ?? primeiroItem?.descricao ?? gestorItem?.descricao ?? "";
      const armazenado = estoqueItem?.armazenado ?? primeiroItem?.qtd_estoque ?? gestorItem?.qtd_estoque ?? 0;
      const valores: Array<string | number | null> = [codigo, descricao ?? "", lote, armazenado];

      for (const [indice, analise] of analisesOrdenadas.entries()) {
        const mapaRodada = mapasRodadas[indice];

        if (!mapaRodada) {
          continue;
        }

        const item = mapaRodada.get(chave);
        const realizou = Boolean(item) && !["AGUARDANDO_CONTAGEM", "SEM_CONTAGEM"].includes(String(item.status).toUpperCase());
        if (analise.numero_rodada >= 3) valores.push(realizou ? "Sim" : "Não");
        valores.push(item?.qtd_contada ?? null, item?.diferenca ?? null);
        if (analise.numero_rodada === 5) valores.push(item?.detalhe ?? "");
      }

      const quantidadeFinal = gestorItem?.quantidade_final_gerencial
        ?? (ultimaAnaliseItem?.resultado_definitivo ? ultimaAnaliseItem.qtd_contada : null);
      valores.push(
        quantidadeFinal,
        quantidadeFinal === null ? null : Number(quantidadeFinal) - Number(armazenado),
        gestorItem?.situacao_gerencial ?? ultimaAnaliseItem?.status ?? "",
        gestorItem?.decisao_gestor.decisao ?? "",
        gestorItem?.decisao_gestor.justificativa ?? "",
      );
      consolidado.addRow(valores);
    }
    consolidado.autoFilter = { from: { row: 4, column: 1 }, to: { row: 4, column: ultimaColuna } };
    largura(consolidado, Array.from({ length: ultimaColuna }, (_, i) => i === 1 ? 38 : i < 4 ? 17 : 15));
    estilizarDados(consolidado, 5, ultimaColuna);
    for (let c = 4; c <= ultimaColuna; c += 1) consolidado.getColumn(c).numFmt = "#,##0.00";

    for (const analise of analisesOrdenadas) {
      const planilha = workbook.addWorksheet(`${analise.numero_rodada}_Contagem`, {
        views: [{ state: "frozen", ySplit: 4 }],
        properties: { defaultRowHeight: 20 },
      });
      const cabecalhos = [
        "Código", "Descrição", "Lote", "Unidade", "Categoria", "Qtd estoque",
        "Qtd contada", "Diferença", "Status", "Resultado definitivo?",
        "Localizações bipadas", "Subtipo divergência", "Detalhe / observação",
      ];
      estilizarTitulo(
        planilha,
        cabecalhos.length,
        `${ordinal(analise.numero_rodada)} - ${detalhe.codigo_inventario}`,
        `Status: ${analise.status_rodada} · Regra: ${analise.regra_conciliacao}`,
      );
      planilha.addRow([]);
      planilha.addRow(cabecalhos);
      estilizarCabecalho(planilha, 4, 1, cabecalhos.length);
      for (const item of analise.itens) {
        planilha.addRow([
          item.codigo, item.descricao ?? "", item.lote ?? "", item.unidade ?? "",
          item.categoria ?? "", item.qtd_estoque, item.qtd_contada, item.diferenca,
          item.status, item.resultado_definitivo ? "Sim" : "Não",
          item.localizacoes_bipadas.map((local) => `${local.localizacao}: ${local.quantidade}`).join("; "),
          item.subtipo_divergencia ?? "", item.detalhe ?? "",
        ]);
      }
      planilha.autoFilter = { from: { row: 4, column: 1 }, to: { row: 4, column: cabecalhos.length } };
      largura(planilha, [18, 40, 18, 12, 18, 15, 15, 15, 20, 18, 40, 22, 40]);
      for (const c of [6, 7, 8]) planilha.getColumn(c).numFmt = "#,##0.00";
      estilizarDados(planilha, 5, cabecalhos.length);
    }
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const nomeSeguro = detalhe.codigo_inventario.replace(/[^a-zA-Z0-9_-]+/g, "-");
  const dataArquivo = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  saveAs(
    new Blob([buffer as BlobPart], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }),
    `SGI_${nomeSeguro}_${dataArquivo}.xlsx`,
  );
}
